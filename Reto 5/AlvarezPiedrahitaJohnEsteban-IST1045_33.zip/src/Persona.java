public abstract class  Persona {

     public abstract int contarExcelentes();
}
